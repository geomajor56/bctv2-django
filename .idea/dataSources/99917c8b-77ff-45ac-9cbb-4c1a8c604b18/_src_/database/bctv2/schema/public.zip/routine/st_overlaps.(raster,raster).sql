create function st_overlaps(rast1 raster, rast2 raster) returns boolean
LANGUAGE SQL
AS $$
SELECT st_overlaps($1, NULL::integer, $2, NULL::integer)
$$;
