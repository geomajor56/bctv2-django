create function st_coveredby(text, text) returns boolean
LANGUAGE SQL
AS $$
SELECT ST_CoveredBy($1::geometry, $2::geometry);
$$;
