create function postgis_scripts_build_date() returns text
LANGUAGE SQL
AS $$
SELECT '2015-08-29 14:09:23'::text AS version
$$;
