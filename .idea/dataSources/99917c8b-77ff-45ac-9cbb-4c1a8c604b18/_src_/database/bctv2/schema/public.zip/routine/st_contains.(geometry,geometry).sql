create function st_contains(geom1 geometry, geom2 geometry) returns boolean
LANGUAGE SQL
AS $$
SELECT $1 && $2 AND _ST_Contains($1,$2)
$$;
