create function st_asgml(text) returns text
LANGUAGE SQL
AS $$
SELECT _ST_AsGML(2,$1::geometry,15,0, NULL, NULL);
$$;
