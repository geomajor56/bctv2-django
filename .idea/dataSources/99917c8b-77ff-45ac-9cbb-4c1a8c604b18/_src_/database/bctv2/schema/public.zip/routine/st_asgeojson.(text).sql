create function st_asgeojson(text) returns text
LANGUAGE SQL
AS $$
SELECT _ST_AsGeoJson(1, $1::geometry,15,0);
$$;
