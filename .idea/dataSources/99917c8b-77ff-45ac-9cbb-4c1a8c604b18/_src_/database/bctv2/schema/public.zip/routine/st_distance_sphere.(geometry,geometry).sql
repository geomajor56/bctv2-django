create function st_distance_sphere(geom1 geometry, geom2 geometry) returns double precision
LANGUAGE SQL
AS $$
select st_distance(geography($1),geography($2),false)

$$;
