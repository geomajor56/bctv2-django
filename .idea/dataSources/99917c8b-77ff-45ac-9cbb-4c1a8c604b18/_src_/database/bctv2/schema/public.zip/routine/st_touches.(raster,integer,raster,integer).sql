create function st_touches(rast1 raster, nband1 integer, rast2 raster, nband2 integer) returns boolean
LANGUAGE SQL
AS $$
SELECT $1 && $3 AND CASE WHEN $2 IS NULL OR $4 IS NULL THEN _st_touches(st_convexhull($1), st_convexhull($3)) ELSE _st_touches($1, $2, $3, $4) END
$$;
