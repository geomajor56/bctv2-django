create function st_histogram(rastertable text, rastercolumn text, nband integer, exclude_nodata_value boolean, bins integer, "right" boolean, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) returns SETOF record
LANGUAGE SQL
AS $$
SELECT _st_histogram($1, $2, $3, $4, 1, $5, NULL, $6)
$$;
