create function st_asgeojson(gj_version integer, geog geography, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0) returns text
LANGUAGE SQL
AS $$
SELECT _ST_AsGeoJson($1, $2, $3, $4);
$$;
