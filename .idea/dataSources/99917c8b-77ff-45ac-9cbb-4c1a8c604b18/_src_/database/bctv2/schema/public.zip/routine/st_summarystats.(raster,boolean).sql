create function st_summarystats(rast raster, exclude_nodata_value boolean, OUT count bigint, OUT sum double precision, OUT mean double precision, OUT stddev double precision, OUT min double precision, OUT max double precision) returns record
LANGUAGE SQL
AS $$
SELECT _st_summarystats($1, 1, $2, 1)
$$;
