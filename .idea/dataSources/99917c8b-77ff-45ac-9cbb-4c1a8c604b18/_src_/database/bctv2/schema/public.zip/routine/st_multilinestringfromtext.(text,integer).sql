create function st_multilinestringfromtext(text, integer) returns geometry
LANGUAGE SQL
AS $$
SELECT ST_MLineFromText($1, $2)
$$;
