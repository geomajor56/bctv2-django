create function st_pixelascentroid(rast raster, x integer, y integer) returns geometry
LANGUAGE SQL
AS $$
SELECT ST_Centroid(geom) FROM _st_pixelaspolygons($1, NULL, $2, $3)
$$;
