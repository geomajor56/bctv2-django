create function st_scale(geometry, double precision, double precision, double precision) returns geometry
LANGUAGE SQL
AS $$
SELECT ST_Affine($1,  $2, 0, 0,  0, $3, 0,  0, 0, $4,  0, 0, 0)
$$;
