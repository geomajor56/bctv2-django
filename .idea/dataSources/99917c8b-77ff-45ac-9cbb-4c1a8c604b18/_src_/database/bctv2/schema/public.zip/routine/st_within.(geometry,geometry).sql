create function st_within(geom1 geometry, geom2 geometry) returns boolean
LANGUAGE SQL
AS $$
SELECT $1 && $2 AND _ST_Contains($2,$1)
$$;
