create function st_asjpeg(rast raster, nbands integer[], options text[] DEFAULT NULL::text[]) returns bytea
LANGUAGE SQL
AS $$
SELECT st_asjpeg(st_band($1, $2), $3)
$$;
