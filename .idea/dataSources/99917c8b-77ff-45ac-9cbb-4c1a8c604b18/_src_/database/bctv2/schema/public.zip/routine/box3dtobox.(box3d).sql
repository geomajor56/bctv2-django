create function box3dtobox(box3d) returns box
LANGUAGE SQL
AS $$
SELECT box($1)
$$;
