create function postgis_scripts_installed() returns text
LANGUAGE SQL
AS $$
SELECT '2.1.8'::text || ' r' || 13780::text AS version
$$;
