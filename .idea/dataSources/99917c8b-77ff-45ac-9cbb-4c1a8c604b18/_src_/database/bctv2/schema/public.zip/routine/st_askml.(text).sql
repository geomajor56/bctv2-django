create function st_askml(text) returns text
LANGUAGE SQL
AS $$
SELECT _ST_AsKML(2, $1::geometry, 15, null);
$$;
