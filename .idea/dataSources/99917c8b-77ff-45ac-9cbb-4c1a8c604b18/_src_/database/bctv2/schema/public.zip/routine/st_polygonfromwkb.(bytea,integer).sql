create function st_polygonfromwkb(bytea, integer) returns geometry
LANGUAGE SQL
AS $$
SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1,$2)) = 'POLYGON'
	THEN ST_GeomFromWKB($1, $2)
	ELSE NULL END

$$;
