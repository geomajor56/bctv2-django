create function st_envelope(raster) returns geometry
LANGUAGE SQL
AS $$
select st_envelope(st_convexhull($1))
$$;
