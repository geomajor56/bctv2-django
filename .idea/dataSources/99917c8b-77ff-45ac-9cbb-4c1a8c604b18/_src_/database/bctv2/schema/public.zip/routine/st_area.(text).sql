create function st_area(text) returns double precision
LANGUAGE SQL
AS $$
SELECT ST_Area($1::geometry);
$$;
