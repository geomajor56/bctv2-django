create function st_aslatlontext(geometry) returns text
LANGUAGE SQL
AS $$
SELECT ST_AsLatLonText($1, '')
$$;
