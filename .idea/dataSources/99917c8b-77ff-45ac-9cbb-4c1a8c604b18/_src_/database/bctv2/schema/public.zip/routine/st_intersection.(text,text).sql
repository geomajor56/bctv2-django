create function st_intersection(text, text) returns geometry
LANGUAGE SQL
AS $$
SELECT ST_Intersection($1::geometry, $2::geometry);
$$;
