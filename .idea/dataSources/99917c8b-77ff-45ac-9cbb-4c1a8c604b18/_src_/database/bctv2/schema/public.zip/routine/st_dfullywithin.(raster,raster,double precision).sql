create function st_dfullywithin(rast1 raster, rast2 raster, distance double precision) returns boolean
LANGUAGE SQL
AS $$
SELECT st_dfullywithin($1, NULL::integer, $2, NULL::integer, $3)
$$;
