create function st_containsproperly(rast1 raster, rast2 raster) returns boolean
LANGUAGE SQL
AS $$
SELECT st_containsproperly($1, NULL::integer, $2, NULL::integer)
$$;
